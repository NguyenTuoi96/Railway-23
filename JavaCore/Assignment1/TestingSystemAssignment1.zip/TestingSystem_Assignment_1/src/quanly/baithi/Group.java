package quanly.baithi;

import java.util.Date;

public class Group {
	int groupId;
	String groupName;
	Account creator;
	Date createDate;
}

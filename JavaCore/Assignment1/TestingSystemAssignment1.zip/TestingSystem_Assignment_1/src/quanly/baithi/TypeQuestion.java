package quanly.baithi;

public class TypeQuestion {
	int typeId;
	TypeName typeName;
}

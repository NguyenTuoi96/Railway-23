package quanly.baithi;

import java.util.Date;

public class GroupAccount {
	Group group;
	Account account;
	Date JoinDate;
}

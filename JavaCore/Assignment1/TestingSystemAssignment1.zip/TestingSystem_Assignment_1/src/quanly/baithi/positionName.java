package quanly.baithi;

public enum positionName {
	DEV, TEST, SCUM_MASTER, PM
}

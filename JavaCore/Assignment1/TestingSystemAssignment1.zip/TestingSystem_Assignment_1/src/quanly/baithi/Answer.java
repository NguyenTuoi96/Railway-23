package quanly.baithi;

public class Answer {
	int answerId;
	String content;
	Question question;
	boolean isCorrect;
}

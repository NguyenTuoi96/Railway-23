package quanly.baithi;

public class Department {
	int departmentId;
	String departmentName;
}

package quanly.baithi;

import java.util.Date;

public class Exam {
	int examId;
	String code;
	String title;
	CategoryQuestion category;
	int duration;
	Account creator;
	Date createDate;
}

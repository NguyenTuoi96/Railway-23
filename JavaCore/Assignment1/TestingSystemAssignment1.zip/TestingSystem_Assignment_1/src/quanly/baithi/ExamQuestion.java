package quanly.baithi;

public class ExamQuestion {
	Exam exam;
	Question question;
}

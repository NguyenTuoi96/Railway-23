package quanly.baithi;

import java.util.Date;

public class Question {
	int questionId;
	String content;
	CategoryQuestion category;
	TypeQuestion type;
	Account creator;
	Date createDate;
}

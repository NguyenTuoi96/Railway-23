package quanly.baithi;

public enum TypeName {
	ESSAY, MULTIPLE_CHOICE
}

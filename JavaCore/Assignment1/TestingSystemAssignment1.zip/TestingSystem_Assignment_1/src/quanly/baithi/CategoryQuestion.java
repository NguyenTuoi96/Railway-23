package quanly.baithi;

public class CategoryQuestion {
	int categoryId;
	String categoryName;
}
